<?php
define('AHC_DS', DIRECTORY_SEPARATOR);
define('AHC_PLUGIN_SUPDIRE_FILE', dirname(__FILE__).'visitors-traffic-real-time-statistics-pro.php');
require_once("settings.php");
require_once("WPHitsCounter.php");

require_once("geoip".AHC_DS."src".AHC_DS."geoip.inc");

register_activation_hook(AHCPRO_PLUGIN_MAIN_FILE, 'ahcpro_set_default_options');
register_deactivation_hook(AHCPRO_PLUGIN_MAIN_FILE, 'ahcpro_unset_default_options');


class GlobalsPro{

	static $plugin_options = array();
	static $lang = NULL;
	static $post_type = NULL; // post | page | category
	static $page_id = NULL;
	static $page_title = NULL;
}

GlobalsPro::$plugin_options = get_option('ahcpro_wp_hits_counter_options');
GlobalsPro::$lang = 'en';


$ahcpro_get_save_settings = ahcpro_get_save_settings();

if($ahcpro_get_save_settings == false or empty($ahcpro_get_save_settings))
{
	ahcpro_add_settings();
}

if(isset($ahcpro_get_save_settings[0]))
{
$hits_days = $ahcpro_get_save_settings[0]->set_hits_days;
$ajax_check = ($ahcpro_get_save_settings[0]->set_ajax_check * 1000);
$set_ips = $ahcpro_get_save_settings[0]->set_ips;
$set_google_map = $ahcpro_get_save_settings[0]->set_google_map;
}else{

$hits_days = 30;
$ajax_check = 10;
$set_ips = '';
$set_google_map = 'today_visitors';
}


define('AHCPRO_VISITORS_VISITS_LIMIT', $hits_days );
define('AHC_AJAX_CHECK', $ajax_check);
define('EXCLUDE_IPS', $set_ips);
define('SET_GOOGLE_MAP', $set_google_map);



$admincore = '';
	if (isset($_GET['page'])) $admincore = $_GET['page'];
	if( is_admin() && $admincore == 'ahc_hits_counter_menu_pro') 
	{
	add_action('admin_enqueue_scripts', 'ahcpro_include_scripts',99);
	}
	

add_action('admin_menu', 'ahcpro_create_admin_menu_link');
add_shortcode('ahcpro_show_google_map', 'ahcpro_google_map' );
//[ahcpro_show_google_map map_status="online"]

add_action('wp_ajax_ahcpro_get_hits_by_custom_duration','ahcpro_get_hits_by_custom_duration_callback');

define('AHCPRO_SERVER_CURRENT_TIMEZONE','+00:00');
?>
