<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">



<!-- Latest compiled and minified JavaScript -->

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>



<script language="javascript" type="text/javascript">

    function imgFlagError(image) {

	image.onerror = "";

	image.src = "<?php echo plugins_url('/images/flags/noFlag.png', AHCPRO_PLUGIN_MAIN_FILE) ?>";

	return true;

    }

</script>

<style type="text/css">

    i{

	color:#999	

    }

</style>



<?php

ahcpro_include_scripts();
$msg = '';

if (!empty($_POST['save'])) {

    if (ahcpro_savesettings()) {

	$msg =('<br /><b style="color:green; margin-left:30px; float:left">settings saved successfully</b><br /><b style=" margin-left:30px; float:left"><a href="admin.php?page=ahc_hits_counter_settings">back to settings</a> | <a href="admin.php?page=ahc_hits_counter_menu_pro">back to dashboard</a></b>');

    }

}



$ahcpro_get_save_settings = ahcpro_get_save_settings();



$hits_days = $ahcpro_get_save_settings[0]->set_hits_days;

$ajax_check = ($ahcpro_get_save_settings[0]->set_ajax_check * 1000);

$set_ips = $ahcpro_get_save_settings[0]->set_ips;

$set_google_map = $ahcpro_get_save_settings[0]->set_google_map;

$delete_plugin_data = get_option('ahcpro_delete_plugin_data_on_uninstall');
$ahcpro_save_ips = get_option('ahcpro_save_ips_opn');

?>

<div class="ahc_main_container" >



    <h1><img width="40px" src="<?php echo plugins_url('/images/logo.png', AHCPRO_PLUGIN_MAIN_FILE) ?>">&nbsp;Visitors Traffic Real Time Statistics pro <a title="change settings" href="admin.php?page=ahc_hits_counter_settings"><img src="<?php echo plugins_url('/images/settings.jpg', AHCPRO_PLUGIN_MAIN_FILE) ?>" /></a></h1><br />

    <div class="panel">

        <h2 class="box-heading">Settings</h2>

	<div class="panelcontent">



	    <form method="post"  enctype="multipart/form-data" name="myform">

		





		<div class="row">



				<div class="form-group col-md-6">

				

					<label for="exampleInput">show hits in last</label>

					<input type="text" value="<?php echo $hits_days ?>" class="form-control" id="set_hits_days" name="set_hits_days" placeholder="Enter number of days">

					<small id="Help" class="form-text text-muted">this will affect the chart in the statistics page. default: 14 day</small>

				</div>

				

				<div class="form-group col-md-2">

				<label for="exampleFormControlSelect1">Select Timezone</label>

					<select class="form-control" id="set_custom_timezone" name="set_custom_timezone">

					 

					<?php

				    $custom_timezone_offset = get_option('ahcpro_custom_timezone');

				    $timezones = DateTimeZone::listIdentifiers(DateTimeZone::ALL);

				    foreach ($timezones as $key => $value) {

					?>

    				    <option value="<?php echo $value; ?>" <?php echo ( $value == $custom_timezone_offset ) ? 'selected' : ''; ?>><?php echo $value; ?></option>

					<?php

				    }

				    ?>

					</select>

				</div>
			<div class="form-group col-md-4">
				<br><span  style="color:red; font-size:13px; ">Please select the same timezone in your</span> <a style="font-size:13px; " href="options-general.php" target="_blank">general settings page</a>
			</div>

					

		</div>

			

			

				

			<div class="row">	

				

				

				<div class="form-group col-md-6">

				

					<label for="exampleInput">check for online users every</label>

					<input type="text" value="<?php echo ($ajax_check / 1000) ?>" class="form-control" id="set_ajax_check" name="set_ajax_check" placeholder="Enter number of days">

					<small id="Help" class="form-text text-muted">Enter total seconds. default: 10 seconds</small>

				

				</div>

				<div class="form-group col-md-6">

					<label for="exampleInput">IP's to exclude</label>

					<textarea placeholder='192.168.0.1' name="set_ips" id="set_ips" rows="3"  class="form-control" ><?php echo $set_ips ?></textarea>

					<small id="Help" class="form-text text-muted">Excluded IPs will not be tracked by your counter, enter IP per line</small>

				</div>

				

				</div>

			<div class="row">
				<div class="form-group col-md-6">

					<label for="exampleInput">Map will display</label>


				<select class="form-control"  name="set_google_map" id="set_google_map" >

				    <option value="today_visitors" <?php

				    if ($set_google_map == 'today_visitors') {

					echo 'selected=selected';

				    }

				    ?> >Today visitors per country</option>
					
					 <option value="all" <?php

				    if ($set_google_map == 'all') {

					echo 'selected=selected';

				    }

				    ?> >Top 10 countries</option>

				    <option value="online" <?php

				    if ($set_google_map == 'online') {

					echo 'selected=selected';

				    }

				    ?> >Online Visitors</option>
					
					
					 <option value="this_month" <?php

				    if ($set_google_map == 'this_month') {

					echo 'selected=selected';

				    }

				    ?> >This Month Visitors</option>
					
					
					 <option value="past_month" <?php

				    if ($set_google_map == 'past_month') {

					echo 'selected=selected';

				    }

				    ?> >Past Month Visitors</option>

				</select>

			    


<br />
			   

			    
</div>
</div>
<div class="row">

				<div class="form-group col-md-6">

					<label for="exampleInput">Stats Data</label>
					<p> <label style="color:red"><input type="checkbox" value="1" name="delete_plugin_data" <?php echo ($delete_plugin_data == 1) ? 'checked=checked' : ''; ?> > If checked, all the stats will be deleted on deleting plugin. </label></p>

			    <br />
					</div>
					
					
			</div>
			</div>

		    </div>

		    <input type="submit" name="save" value="save settings" style="font-size:15px" />

		    <input type="button" name="cancel" value="back to dashboard" onclick="javascript:window.location.href = 'admin.php?page=ahc_hits_counter_menu_pro'" style="font-size:15px" />

		</div>
<?php
echo $msg;
	?>
	    </form>

	
