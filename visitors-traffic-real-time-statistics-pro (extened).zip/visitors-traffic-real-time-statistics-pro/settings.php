<?php
define('AHCPRO_RECENT_VISITORS_LIMIT', 20);
define('AHCPRO_RECENT_KEYWORDS_LIMIT', 20);
define('AHCPRO_VISITORS_VISITS_SUMMARY_LIMIT', 20); // used in ahc_get_ser_visits_by_date & search engines last days
define('AHCPRO_TOP_REFERING_SITES_LIMIT', 20); // used in ahcpro_get_top_refering_sites
define('AHCPRO_TOP_COUNTRIES_LIMIT', 20); // used in ahcpro_get_top_countries


define('AHCPRO_TRAFFIC_BY_TITLE_LIMIT', 20);
define('IS_DEMO', true);
