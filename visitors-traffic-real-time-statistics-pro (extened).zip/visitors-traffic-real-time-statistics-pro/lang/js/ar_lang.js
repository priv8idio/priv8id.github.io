
var ahc_visitors = 'الزوار';
var ahc_visits = 'المشاهدات';
var ahc_no_visits_visitors = 'عدد الزوار والزيارات';
var ahc_no_visits = 'عدد الزيارات';