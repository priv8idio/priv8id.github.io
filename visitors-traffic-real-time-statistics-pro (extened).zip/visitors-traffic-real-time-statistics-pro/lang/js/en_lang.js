
var ahc_visitors = 'Visitors';
var ahc_visits = 'Visits';
var ahc_no_visits_visitors = 'Number of visitors and visits';
var ahc_no_visits = 'Number of visits';
