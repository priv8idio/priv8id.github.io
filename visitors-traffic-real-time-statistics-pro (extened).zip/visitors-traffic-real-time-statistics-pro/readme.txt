=== Visitor Traffic Real Time Statistics pro ===
Contributors: wp-buy
Tags: online, Visitor, Stats, Counter, hits, visits, statistics, chart, counter, diagram, graph, traffic
Requires at least: 3.0.1
Tested up to: 5.2.3
Stable tag: 5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Counter and statistics plugin for WordPress to display your WordPress blog statistics and traffic. Ranging from general total statistics

== Description ==

Visitors Traffic Real Time Statistics is a Counter and statistics plugin for WordPress to display your WordPress blog statistics and traffic. Ranging from general total statistics
This plugin will help you to track your visitors, browsers, operating systems, visits and much more, Track statistics for your WordPress site without depending on external services



== Installation ==

1. Remove the demo plugin from your plugins page
2. Download the package.
3. Extract the contents of .zip folder to wp-content/plugins/ folder or upload it using your pligins page > add new > upload
4. Activate the Plugin.
5. Go to your main menu > visitors traffic.

Thanks!


== Basic Features: ==
1. Comprehensive overview page (Dashboard), including browser versions, country stats, hits, exclusions, referrers, searches, search words and visitors
2. Visits, see how many hits your site gets each day and each week & month
3. Visitors, see who's visiting your site
4. see how many people are viewing your site by daily and weekly and monthly staticts
5. Page tracking, see which pages are viewed most often
6. Search Engines, see search queries and redirects from popular search engines like Google, Bing, DuckDuckGo, Yahoo, Yandex and Baidu
7. visitors locations by Countries
8. Interactive map of visitors location
9. Automatic updates to the GeoIP database
10. Widget to provide information to your user


== Changelog ==

= 5.3 =
1. adding new option in the settings page to display the current month visitors or the past month visitors for the map  


= 5.2 =
1. Bug fixing in online users - reported by Mr. Ioannis Zagkaretos


= 5.1 =
1. Bug fixing in ip execluding


= 4.9 =
1. Bug fixing in CSS


= 4.8 =
1. CSRF bug fixing visitors time graph - reported by Mr. Justin Neway
2. adding new feature (search by date range) as per Mr. Justin Neway request


= 4.7 =
1. CSRF bug fixing in settings page (prevent SQL injection) - reported by Mr. Paul

= 4.6 =
1. fix time graph issue
2. Reports improvements

= 4.5 =
1. bug fixing in UTC
2. bug fixing in execluding IPs
3. Reports improvements


= 4.4 =
1. bug fixing timezone (UTC issue) in sime places

= 4.3 =
1. bug fixing in datatable
2. bug fixing in recent visitors by IP (get cities)


= 4.2 =
1. timezone bug fixing in the time graph
2. enhancements in map
3. bug fixing in export data & pagination
4. add new optin in the map settings to show the traffic for the top 10 countries


= 4.1 =
1. bug fixing in timezone settings

= 4 =
1. replace the google map with openstreetmap
2. desing enhancements
3. adding search filters for most box's
4. adding export to excel for all stats box's
5. adding pagination to all stats box's
6. PHP 7 bug fixes
7. upgrade the update checker plugin to be compatible with php 7


= 3.14 =
1. bug fixing in IP location API

= 3.13 =
1. better font type
2. adding clock for currect date and time

= 3.12 =
1. bug fixing in IP forwarding

= 3.11 =
1. Make charts responsive

= 3.10 =
1. Give the user the ability to hide/show visitors IP's (new option in the settings page)

= 3.9 =
1. EU GDPR Compatible
2. Latest search words improvements

= 3.8 =
1. Fixing widgets issue

= 3.7 =
1. online users bug fixing
2. Fix updater problem with new php7

= 3.6 =
1. fixing timezone calculation in minus

= 3.5 =
1. Fixing settings page layout issue
2. fixing timezone issue for EU users

= 3.4 =
1. Add the ability to change the timezone
2. support caching

= 3.3 =
1. Fixing timezone issues

= 3.2 =
1. Fix updater problem with new php7

= 3.0.0.27 =
1. Google map short-code & settings

= 3.0.0.26 =
1. change plugin methods

= 3.0.0.25 =
1. bug fixing in settings

= 3.0.0.24 =
1. bug fixing - ajax bug

= 3.0.0.23 =
1. change plugin update method

= 3.0.0.22 =
1. Support cities and regions 

= 3.0.0.21 =
1. Bug fixing

= 3.0.0.20 =
1. adding new box for today traffic index by country

= 3.0.0.19 =
1. date formatting
2. Bug fixing

= 3.0.0.18 =
1. add settings page
2. add help page

= 3.0.0.17 =
solving issue with mobiles browsers

= 3.0.0.16 =
1. upgrade charts

= 3.0.0.15 =
1. fixing bugs

= 3.0.0.14 =
1. Bug fixing - Recording sub pages. Fixed by Glenn Rowe 

= 3.0.0.13 =
1. upgrade online users to support AJAX


= 3.0.0.5 =
1. fixing bugs
2. change daily visits time graph to be beautiful

= 3.0.0.4 =
1. adding new box for geo locations
2. change styles

= 3.0.0.3 =
1. upgrade charts to be beautiful


= 3.0.0.2 =
1. upgrade graphs & charts
2. adding geoIP locations
3. fixing errors


= 3.0.0.1 =
1. Initial version
2. adding colors to 
